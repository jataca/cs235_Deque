/***********************************************************************
 * Header:
 *    NOW SERVING
 * Summary:
 *    This is just the prototype for nowServing(). The entire
 *    implementation can be found in nowServing.cpp
 * Author
 *    Justin Stucki <0 Hrs> //That's just for this header file :)
 ************************************************************************/

#ifndef NOW_SERVING_H
#define NOW_SERVING_H

#include "deque.h"     // for DEQUE
//#include <deque>

// the interactive nowServing program
void nowServing();

#endif // NOW_SERVING_H

